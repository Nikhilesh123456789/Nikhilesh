import './App.css';
import NobelPrize from './NobelPrize';
import { Routes, Route } from "react-router-dom"
import Filter from './Filter';
import { BrowserRouter } from "react-router-dom";

function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
           <Route path="/"element={<NobelPrize/>} />
           <Route path='/filter' element={<Filter/>} />
        </Routes>
        </BrowserRouter>
    </div>
  );
}

export default App;
