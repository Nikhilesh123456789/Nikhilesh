import React, { useState, useEffect } from 'react'
import './App.css';
import { useNavigate } from 'react-router-dom';

function NobelPrize() {
    const [winners, setWinners] = useState({});

    useEffect(() => {
        (async () => {
            let winnersList = {};
            let promise = await fetch('./prize.json');
            let data = await promise.json();
            data.prizes.map(item => {
                let category = item.category;
                if (!(category in winnersList)) {
                    winnersList[category] = []
                }
                if ("laureates" in item) {
                    item.laureates.map(personData => {
                        winnersList[category].push([{
                            "name": personData.firstname + personData.surname,
                            "year": item.year
                        }])
                    })
                }
            })
            setWinners(winnersList);
        })();
    }, [])

    const navigate = useNavigate();
  

    function filter(){
        navigate('/filter');
    }

    return (
        <>
            <span>
                <h2 style={{color:"blue"}}>Details of the prize winners</h2>
                <h2 style={{color:"red"}}>Want to filter? click here..</h2>
                <button style={{lineHeight:"1cm",width:"100px"}} onClick={filter}>Filter</button><br/><br/>
            </span>
            <div>
                <table >
                    <tbody>
                        {
                            Object.keys(winners).map(key => {
                                return (
                                    <>
                                        <tr>
                                            <td>Category {<b style={{ color: "red" }}>{key}</b>}</td>
                                            {winners[key].map(val => {
                                                return (
                                                    <>
                                                        <td>
                                                            <b>Name</b><br />
                                                            {val[0].name} <br />
                                                            <b>year</b><br />
                                                            {val[0].year}
                                                        </td>
                                                    </>
                                                )
                                            })}
                                        </tr>
                                    </>
                                )
                            })
                        }
                    </tbody>
                </table>
            </div>
        </>
    )
}
export default NobelPrize;