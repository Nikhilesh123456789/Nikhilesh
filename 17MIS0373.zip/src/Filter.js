import React, { useState } from 'react'

function Filter() {

    const [category, setCategory] = useState("");
    const [year, setYear] = useState("");
    const [winners, setWinners] = useState({});

    function handleCategoryChange(eve) {
        setCategory(eve.target.value);
    }

    function handleYearChange(eve) {
        setYear(eve.target.value);
    }

    async function save() {
        let winnersList = {};
        let promise = await fetch('./prize.json');
        let data = await promise.json();
        data.prizes.map(item => {
            let cat = item.category;
            let yr = item.year;
            if (cat === category && item.year === year) {
                console.log(item)
                if (!(cat in winnersList)) {
                    winnersList[cat] = []
                }
                if ("laureates" in item) {
                    item.laureates.map(personData => {
                        winnersList[cat].push([{
                            "name": personData.firstname + personData.surname,
                            "year": item.year
                        }])
                    })
                }
                setWinners(winnersList);
            }
        })
    }

    return (
        <>
            <h2 style={{color:"red"}}>Filter here...</h2>
            Select Category{' '}
            <select onChange={handleCategoryChange}>
                <option selected>Select</option>
                <option name='chemistry'>chemistry</option>
                <option name='economics'>economics</option>
                <option name='literature'>literature</option>
                <option name='peace'>peace</option>
                <option name='physics'>physics</option>
                <option name='medicine'>medicine</option>
            </select>
            <br /><br />
            Enter Year (b/w 1900-2018){' '}
            <input type='text' onChange={handleYearChange} /><br /><br />
            <button onClick={save}>Submit</button>
            <h2>{`Details of the winner:- (category) ${category} , (year) ${year}`}</h2>
            <br />
            <div>
                <table >
                    <tbody>
                        {
                            Object.keys(winners).map(key => {
                                return (
                                    <>
                                        <tr>
                                            <td>Category {<b style={{ color: "red" }}>{key}</b>}</td>
                                            {winners[key].map(val => {
                                                return (
                                                    <>
                                                        <td>
                                                            <b>Name</b><br />
                                                            {val[0].name} <br />
                                                            <b>year</b><br />
                                                            {val[0].year}
                                                        </td>
                                                    </>
                                                )
                                            })}
                                        </tr>
                                    </>
                                )
                            })
                        }
                    </tbody>
                </table>
            </div>
        </>
    )
}

export default Filter